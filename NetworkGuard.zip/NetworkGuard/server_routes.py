from flask import render_template, request, redirect, url_for, flash, jsonify, session
from app import app, db
import models
from auth import login_required, role_required
from datetime import datetime

@app.route('/api/servers')
@login_required
def api_servers():
    servers = models.Server.query.all()
    return jsonify([server.to_dict() for server in servers])

@app.route('/api/server_stats')
@login_required
def api_server_stats():
    servers = models.Server.query.all()
    
    # Storage utilization data for pie chart
    storage_data = {}
    for server in servers:
        if server.storage_utilization:
            if server.storage_utilization < 50:
                storage_data['Low (< 50%)'] = storage_data.get('Low (< 50%)', 0) + 1
            elif server.storage_utilization < 80:
                storage_data['Medium (50-80%)'] = storage_data.get('Medium (50-80%)', 0) + 1
            else:
                storage_data['High (> 80%)'] = storage_data.get('High (> 80%)', 0) + 1
    
    # Backup status data for bar chart
    backup_data = {
        'successful': sum(server.backup_taken for server in servers if server.backup_taken),
        'failed': sum(server.failed_backup for server in servers if server.failed_backup)
    }
    
    # System status data for line chart (simplified - using current status)
    status_data = {
        'running': sum(1 for server in servers if server.system_running),
        'stopped': sum(1 for server in servers if not server.system_running)
    }
    
    return jsonify({
        'storage_utilization': storage_data,
        'backup_status': backup_data,
        'system_status': status_data
    })

@app.route('/server/add', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Engineer'])
def add_server():
    if request.method == 'POST':
        server = models.Server(
            server_name=request.form['server_name'],
            ip_address=request.form['ip_address'],
            space_utilization=float(request.form.get('space_utilization', 0)),
            hardware_status=request.form.get('hardware_status', 'Good'),
            volumes_status=request.form.get('volumes_status', 'Good'),
            remarks=request.form.get('remarks', ''),
            alerts_status=request.form.get('alerts_status', 'Normal'),
            system_running=request.form.get('system_running') == 'on',
            overall_status=request.form.get('overall_status', 'Healthy'),
            status_by_volume=request.form.get('status_by_volume', ''),
            protection_group=request.form.get('protection_group', ''),
            failed_backup=int(request.form.get('failed_backup', 0)),
            backup_taken=int(request.form.get('backup_taken', 0)),
            size=request.form.get('size', ''),
            task_status=request.form.get('task_status', 'Completed'),
            storage_utilization=float(request.form.get('storage_utilization', 0)),
            created_by=session['user_id']
        )
        
        db.session.add(server)
        db.session.commit()
        
        # Log the action
        log = models.Log(
            action='Server Added',
            user_id=session['user_id'],
            server_id=server.id,
            details=f'Added server {server.server_name} ({server.ip_address})'
        )
        db.session.add(log)
        db.session.commit()
        
        flash(f'Server {server.server_name} added successfully', 'success')
        return redirect(url_for('index'))
    
    return render_template('server_form.html', action='Add', server=None)

@app.route('/server/edit/<int:server_id>', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Engineer'])
def edit_server(server_id):
    server = models.Server.query.get_or_404(server_id)
    
    if request.method == 'POST':
        server.server_name = request.form['server_name']
        server.ip_address = request.form['ip_address']
        server.space_utilization = float(request.form.get('space_utilization', 0))
        server.hardware_status = request.form.get('hardware_status', 'Good')
        server.volumes_status = request.form.get('volumes_status', 'Good')
        server.remarks = request.form.get('remarks', '')
        server.alerts_status = request.form.get('alerts_status', 'Normal')
        server.system_running = request.form.get('system_running') == 'on'
        server.overall_status = request.form.get('overall_status', 'Healthy')
        server.status_by_volume = request.form.get('status_by_volume', '')
        server.protection_group = request.form.get('protection_group', '')
        server.failed_backup = int(request.form.get('failed_backup', 0))
        server.backup_taken = int(request.form.get('backup_taken', 0))
        server.size = request.form.get('size', '')
        server.task_status = request.form.get('task_status', 'Completed')
        server.storage_utilization = float(request.form.get('storage_utilization', 0))
        server.last_updated = datetime.utcnow()
        
        db.session.commit()
        
        # Log the action
        log = models.Log(
            action='Server Updated',
            user_id=session['user_id'],
            server_id=server.id,
            details=f'Updated server {server.server_name} ({server.ip_address})'
        )
        db.session.add(log)
        db.session.commit()
        
        flash(f'Server {server.server_name} updated successfully', 'success')
        return redirect(url_for('index'))
    
    return render_template('server_form.html', action='Edit', server=server)

@app.route('/server/delete/<int:server_id>')
@login_required
@role_required(['Admin', 'Engineer'])
def delete_server(server_id):
    server = models.Server.query.get_or_404(server_id)
    server_name = server.server_name
    
    db.session.delete(server)
    db.session.commit()
    
    # Log the action
    log = models.Log(
        action='Server Deleted',
        user_id=session['user_id'],
        details=f'Deleted server {server_name}'
    )
    db.session.add(log)
    db.session.commit()
    
    flash(f'Server {server_name} deleted successfully', 'success')
    return redirect(url_for('index'))
