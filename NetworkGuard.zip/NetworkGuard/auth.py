from flask import render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from app import app, db
import models

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return redirect(url_for('login'))
            
            user = models.User.query.get(session['user_id'])
            if not user or user.role not in roles:
                flash('Access denied. Insufficient permissions.', 'error')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = models.User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            
            # Log the login
            log = models.Log(
                action='User Login',
                user_id=user.id,
                details=f'User {username} logged in'
            )
            db.session.add(log)
            db.session.commit()
            
            flash(f'Welcome back, {user.username}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    if 'user_id' in session:
        # Log the logout
        log = models.Log(
            action='User Logout',
            user_id=session['user_id'],
            details=f'User {session.get("username")} logged out'
        )
        db.session.add(log)
        db.session.commit()
    
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('login'))

@app.route('/admin/dashboard')
@login_required
@role_required(['Admin'])
def admin_dashboard():
    servers = models.Server.query.all()
    users = models.User.query.all()
    recent_logs = models.Log.query.order_by(models.Log.timestamp.desc()).limit(10).all()
    
    # Calculate stats
    total_servers = len(servers)
    running_servers = sum(1 for s in servers if s.system_running)
    critical_servers = sum(1 for s in servers if s.overall_status == 'Critical')
    
    return render_template('admin_dashboard.html', 
                         servers=servers, 
                         users=users, 
                         recent_logs=recent_logs,
                         total_servers=total_servers,
                         running_servers=running_servers,
                         critical_servers=critical_servers)

@app.route('/engineer/dashboard')
@login_required
@role_required(['Admin', 'Engineer'])
def engineer_dashboard():
    servers = models.Server.query.all()
    
    # Calculate stats
    total_servers = len(servers)
    running_servers = sum(1 for s in servers if s.system_running)
    critical_servers = sum(1 for s in servers if s.overall_status == 'Critical')
    
    return render_template('engineer_dashboard.html', 
                         servers=servers,
                         total_servers=total_servers,
                         running_servers=running_servers,
                         critical_servers=critical_servers)

@app.route('/viewer/dashboard')
@login_required
@role_required(['Admin', 'Engineer', 'Viewer'])
def viewer_dashboard():
    servers = models.Server.query.all()
    
    # Calculate stats
    total_servers = len(servers)
    running_servers = sum(1 for s in servers if s.system_running)
    critical_servers = sum(1 for s in servers if s.overall_status == 'Critical')
    
    return render_template('viewer_dashboard.html', 
                         servers=servers,
                         total_servers=total_servers,
                         running_servers=running_servers,
                         critical_servers=critical_servers)

@app.route('/admin/manage_users')
@login_required
@role_required(['Admin'])
def manage_users():
    users = models.User.query.all()
    return render_template('manage_users.html', users=users)

@app.route('/admin/create_user', methods=['POST'])
@login_required
@role_required(['Admin'])
def create_user():
    username = request.form['username']
    password = request.form['password']
    role = request.form['role']
    
    if models.User.query.filter_by(username=username).first():
        flash('Username already exists', 'error')
        return redirect(url_for('manage_users'))
    
    user = models.User(
        username=username,
        password_hash=generate_password_hash(password),
        role=role
    )
    
    db.session.add(user)
    db.session.commit()
    
    # Log the action
    log = models.Log(
        action='User Created',
        user_id=session['user_id'],
        details=f'Created user {username} with role {role}'
    )
    db.session.add(log)
    db.session.commit()
    
    flash(f'User {username} created successfully', 'success')
    return redirect(url_for('manage_users'))

@app.route('/admin/delete_user/<int:user_id>')
@login_required
@role_required(['Admin'])
def delete_user(user_id):
    if user_id == session['user_id']:
        flash('Cannot delete your own account', 'error')
        return redirect(url_for('manage_users'))
    
    user = models.User.query.get_or_404(user_id)
    username = user.username
    
    db.session.delete(user)
    db.session.commit()
    
    # Log the action
    log = models.Log(
        action='User Deleted',
        user_id=session['user_id'],
        details=f'Deleted user {username}'
    )
    db.session.add(log)
    db.session.commit()
    
    flash(f'User {username} deleted successfully', 'success')
    return redirect(url_for('manage_users'))
