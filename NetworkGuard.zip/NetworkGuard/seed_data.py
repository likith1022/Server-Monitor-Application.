from app import app, db
from models import User, Server, Log
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random

def create_seed_data():
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()
        
        # Create default users
        admin = User(
            username='admin',
            password_hash=generate_password_hash('admin123'),
            role='Admin'
        )
        
        engineer1 = User(
            username='engineer1',
            password_hash=generate_password_hash('eng123'),
            role='Engineer'
        )
        
        engineer2 = User(
            username='engineer2',
            password_hash=generate_password_hash('eng123'),
            role='Engineer'
        )
        
        viewer1 = User(
            username='viewer1',
            password_hash=generate_password_hash('view123'),
            role='Viewer'
        )
        
        viewer2 = User(
            username='viewer2',
            password_hash=generate_password_hash('view123'),
            role='Viewer'
        )
        
        db.session.add_all([admin, engineer1, engineer2, viewer1, viewer2])
        db.session.commit()
        
        # Create sample servers
        servers_data = [
            {
                'server_name': 'Web-Server-01',
                'ip_address': '192.168.1.10',
                'space_utilization': 75.5,
                'hardware_status': 'Good',
                'volumes_status': 'Good',
                'remarks': 'Primary web server running Apache',
                'alerts_status': 'Normal',
                'system_running': True,
                'overall_status': 'Healthy',
                'status_by_volume': 'All volumes healthy',
                'protection_group': 'Web-Servers',
                'failed_backup': 0,
                'backup_taken': 30,
                'size': '500GB',
                'task_status': 'Completed',
                'storage_utilization': 82.3
            },
            {
                'server_name': 'DB-Server-01',
                'ip_address': '192.168.1.20',
                'space_utilization': 89.2,
                'hardware_status': 'Warning',
                'volumes_status': 'Good',
                'remarks': 'Database server needs disk cleanup',
                'alerts_status': 'Warning',
                'system_running': True,
                'overall_status': 'Warning',
                'status_by_volume': 'Volume C: 90% full',
                'protection_group': 'Database-Servers',
                'failed_backup': 2,
                'backup_taken': 28,
                'size': '2TB',
                'task_status': 'In Progress',
                'storage_utilization': 95.7
            },
            {
                'server_name': 'App-Server-01',
                'ip_address': '192.168.1.30',
                'space_utilization': 45.8,
                'hardware_status': 'Good',
                'volumes_status': 'Good',
                'remarks': 'Application server running smoothly',
                'alerts_status': 'Normal',
                'system_running': True,
                'overall_status': 'Healthy',
                'status_by_volume': 'All volumes optimal',
                'protection_group': 'App-Servers',
                'failed_backup': 0,
                'backup_taken': 30,
                'size': '1TB',
                'task_status': 'Completed',
                'storage_utilization': 67.4
            },
            {
                'server_name': 'File-Server-01',
                'ip_address': '192.168.1.40',
                'space_utilization': 92.1,
                'hardware_status': 'Critical',
                'volumes_status': 'Warning',
                'remarks': 'File server requires immediate attention - disk almost full',
                'alerts_status': 'Critical',
                'system_running': True,
                'overall_status': 'Critical',
                'status_by_volume': 'Multiple volumes above 90%',
                'protection_group': 'File-Servers',
                'failed_backup': 5,
                'backup_taken': 25,
                'size': '5TB',
                'task_status': 'Failed',
                'storage_utilization': 98.2
            },
            {
                'server_name': 'Backup-Server-01',
                'ip_address': '192.168.1.50',
                'space_utilization': 34.7,
                'hardware_status': 'Good',
                'volumes_status': 'Good',
                'remarks': 'Backup server operating normally',
                'alerts_status': 'Normal',
                'system_running': True,
                'overall_status': 'Healthy',
                'status_by_volume': 'All backup volumes healthy',
                'protection_group': 'Backup-Servers',
                'failed_backup': 1,
                'backup_taken': 29,
                'size': '10TB',
                'task_status': 'Completed',
                'storage_utilization': 45.6
            },
            {
                'server_name': 'Test-Server-01',
                'ip_address': '192.168.1.60',
                'space_utilization': 12.3,
                'hardware_status': 'Good',
                'volumes_status': 'Good',
                'remarks': 'Test environment server',
                'alerts_status': 'Normal',
                'system_running': False,
                'overall_status': 'Offline',
                'status_by_volume': 'Server offline for maintenance',
                'protection_group': 'Test-Servers',
                'failed_backup': 0,
                'backup_taken': 15,
                'size': '250GB',
                'task_status': 'Scheduled',
                'storage_utilization': 23.1
            }
        ]
        
        for server_data in servers_data:
            server = Server(**server_data, created_by=admin.id)
            db.session.add(server)
        
        db.session.commit()
        
        # Create some sample logs
        servers = Server.query.all()
        users = User.query.all()
        
        log_actions = [
            'Server Added',
            'Server Updated',
            'Server Deleted',
            'User Login',
            'User Logout',
            'System Check',
            'Backup Initiated',
            'Alert Acknowledged'
        ]
        
        for i in range(20):
            log = Log(
                action=random.choice(log_actions),
                user_id=random.choice(users).id,
                server_id=random.choice(servers).id if random.choice([True, False]) else None,
                timestamp=datetime.utcnow() - timedelta(days=random.randint(0, 30)),
                details=f'Sample log entry {i+1}'
            )
            db.session.add(log)
        
        db.session.commit()
        
        print("Seed data created successfully!")
        print("\nDefault users created:")
        print("Admin: admin / admin123")
        print("Engineer: engineer1 / eng123")
        print("Engineer: engineer2 / eng123")
        print("Viewer: viewer1 / view123")
        print("Viewer: viewer2 / view123")

if __name__ == '__main__':
    create_seed_data()
