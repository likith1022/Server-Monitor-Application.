// Charts functionality for Server Monitor
document.addEventListener('DOMContentLoaded', function() {
    // Chart.js default configuration
    Chart.defaults.color = '#ffffff';
    Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.1)';
    Chart.defaults.backgroundColor = 'rgba(255, 255, 255, 0.1)';

    // Fetch server statistics from API
    async function fetchServerStats() {
        try {
            const response = await fetch('/api/server_stats');
            if (!response.ok) {
                throw new Error('Failed to fetch server stats');
            }
            return await response.json();
        } catch (error) {
            console.error('Error fetching server stats:', error);
            return null;
        }
    }

    // Storage Utilization Pie Chart
    async function createStorageChart() {
        const storageCanvas = document.getElementById('storageChart');
        if (!storageCanvas) return;

        const data = await fetchServerStats();
        if (!data || !data.storage_utilization) return;

        const ctx = storageCanvas.getContext('2d');
        
        const chartData = {
            labels: Object.keys(data.storage_utilization),
            datasets: [{
                data: Object.values(data.storage_utilization),
                backgroundColor: [
                    '#198754', // Green for low
                    '#ffc107', // Yellow for medium
                    '#dc3545'  // Red for high
                ],
                borderColor: '#ffffff',
                borderWidth: 2
            }]
        };

        new Chart(ctx, {
            type: 'pie',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Storage Utilization Distribution',
                        color: '#ffffff'
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#ffffff',
                            padding: 20
                        }
                    }
                }
            }
        });
    }

    // Backup Status Bar Chart
    async function createBackupChart() {
        const backupCanvas = document.getElementById('backupChart');
        if (!backupCanvas) return;

        const data = await fetchServerStats();
        if (!data || !data.backup_status) return;

        const ctx = backupCanvas.getContext('2d');
        
        const chartData = {
            labels: ['Successful', 'Failed'],
            datasets: [{
                label: 'Backup Count',
                data: [data.backup_status.successful || 0, data.backup_status.failed || 0],
                backgroundColor: [
                    '#198754', // Green for successful
                    '#dc3545'  // Red for failed
                ],
                borderColor: '#ffffff',
                borderWidth: 1
            }]
        };

        new Chart(ctx, {
            type: 'bar',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Backup Success vs Failures',
                        color: '#ffffff'
                    },
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#ffffff',
                            stepSize: 1
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#ffffff'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                }
            }
        });
    }

    // System Status Line Chart (Simplified for demo)
    async function createSystemChart() {
        const systemCanvas = document.getElementById('systemChart');
        if (!systemCanvas) return;

        const data = await fetchServerStats();
        if (!data || !data.system_status) return;

        const ctx = systemCanvas.getContext('2d');
        
        // Generate some sample time-based data for demonstration
        const labels = [];
        const runningData = [];
        const stoppedData = [];
        
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString());
            
            // Simulate some variation in the data
            runningData.push(data.system_status.running + Math.floor(Math.random() * 3) - 1);
            stoppedData.push(data.system_status.stopped + Math.floor(Math.random() * 2));
        }

        const chartData = {
            labels: labels,
            datasets: [
                {
                    label: 'Running Systems',
                    data: runningData,
                    borderColor: '#198754',
                    backgroundColor: 'rgba(25, 135, 84, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Stopped Systems',
                    data: stoppedData,
                    borderColor: '#dc3545',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    tension: 0.4,
                    fill: true
                }
            ]
        };

        new Chart(ctx, {
            type: 'line',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'System Status Trend (Last 7 Days)',
                        color: '#ffffff'
                    },
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#ffffff'
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#ffffff',
                            stepSize: 1
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#ffffff'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                }
            }
        });
    }

    // Real-time updates for charts
    function scheduleChartUpdates() {
        // Update charts every 5 minutes
        setInterval(async () => {
            try {
                // Destroy existing charts and recreate with new data
                Chart.helpers.each(Chart.instances, function(instance) {
                    instance.destroy();
                });
                
                await createStorageChart();
                await createBackupChart();
                await createSystemChart();
                
                console.log('Charts updated successfully');
            } catch (error) {
                console.error('Error updating charts:', error);
            }
        }, 300000); // 5 minutes
    }

    // Initialize all charts
    async function initializeCharts() {
        try {
            await createStorageChart();
            await createBackupChart();
            await createSystemChart();
            
            // Schedule periodic updates
            scheduleChartUpdates();
            
            console.log('All charts initialized successfully');
        } catch (error) {
            console.error('Error initializing charts:', error);
        }
    }

    // Start chart initialization
    initializeCharts();
});

// Utility function to generate chart colors
function generateChartColors(count) {
    const colors = [
        '#198754', '#dc3545', '#ffc107', '#0d6efd', '#6610f2',
        '#6f42c1', '#d63384', '#fd7e14', '#20c997', '#0dcaf0'
    ];
    
    const result = [];
    for (let i = 0; i < count; i++) {
        result.push(colors[i % colors.length]);
    }
    return result;
}

// Function to export chart as image
function exportChartAsImage(chartId, filename = 'chart.png') {
    const canvas = document.getElementById(chartId);
    if (canvas) {
        const link = document.createElement('a');
        link.download = filename;
        link.href = canvas.toDataURL();
        link.click();
    }
}
