// Dashboard functionality
document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh functionality
    let autoRefreshInterval;
    const refreshButton = document.getElementById('refreshButton');
    
    // Tooltip initialization
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Progress bar animations
    function animateProgressBars() {
        const progressBars = document.querySelectorAll('.progress-bar');
        progressBars.forEach(bar => {
            const width = bar.style.width;
            bar.style.width = '0%';
            setTimeout(() => {
                bar.style.width = width;
            }, 100);
        });
    }

    // Call progress bar animation on load
    animateProgressBars();

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Search functionality for tables
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const tableRows = document.querySelectorAll('tbody tr');
            
            tableRows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }

    // Auto-refresh toggle
    function toggleAutoRefresh() {
        if (autoRefreshInterval) {
            clearInterval(autoRefreshInterval);
            autoRefreshInterval = null;
            if (refreshButton) {
                refreshButton.innerHTML = '<i class="fas fa-play me-1"></i>Start Auto Refresh';
                refreshButton.classList.remove('btn-danger');
                refreshButton.classList.add('btn-success');
            }
        } else {
            autoRefreshInterval = setInterval(() => {
                window.location.reload();
            }, 30000); // Refresh every 30 seconds
            
            if (refreshButton) {
                refreshButton.innerHTML = '<i class="fas fa-stop me-1"></i>Stop Auto Refresh';
                refreshButton.classList.remove('btn-success');
                refreshButton.classList.add('btn-danger');
            }
        }
    }

    // Bind auto-refresh button
    if (refreshButton) {
        refreshButton.addEventListener('click', toggleAutoRefresh);
    }

    // Status badge color updates
    function updateStatusBadges() {
        const badges = document.querySelectorAll('.badge');
        badges.forEach(badge => {
            const text = badge.textContent.toLowerCase();
            badge.classList.remove('bg-success', 'bg-warning', 'bg-danger', 'bg-secondary');
            
            if (text.includes('healthy') || text.includes('good') || text.includes('normal') || text.includes('running')) {
                badge.classList.add('bg-success');
            } else if (text.includes('warning')) {
                badge.classList.add('bg-warning');
            } else if (text.includes('critical') || text.includes('failed')) {
                badge.classList.add('bg-danger');
            } else {
                badge.classList.add('bg-secondary');
            }
        });
    }

    // Update status badges on load
    updateStatusBadges();

    // Confirmation dialogs
    const deleteButtons = document.querySelectorAll('[data-confirm]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            const message = this.getAttribute('data-confirm') || 'Are you sure?';
            if (!confirm(message)) {
                event.preventDefault();
            }
        });
    });

    // Flash message auto-dismiss
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Real-time clock
    function updateClock() {
        const clockElement = document.getElementById('currentTime');
        if (clockElement) {
            const now = new Date();
            clockElement.textContent = now.toLocaleString();
        }
    }

    // Update clock every second
    setInterval(updateClock, 1000);
    updateClock(); // Initial call

    // Keyboard shortcuts
    document.addEventListener('keydown', function(event) {
        // Ctrl/Cmd + R for refresh
        if ((event.ctrlKey || event.metaKey) && event.key === 'r') {
            event.preventDefault();
            window.location.reload();
        }
        
        // Escape to close modals
        if (event.key === 'Escape') {
            const openModals = document.querySelectorAll('.modal.show');
            openModals.forEach(modal => {
                const bsModal = bootstrap.Modal.getInstance(modal);
                if (bsModal) {
                    bsModal.hide();
                }
            });
        }
    });

    // Network status indicator
    function updateNetworkStatus() {
        const statusIndicator = document.getElementById('networkStatus');
        if (statusIndicator) {
            if (navigator.onLine) {
                statusIndicator.innerHTML = '<i class="fas fa-wifi text-success"></i>';
                statusIndicator.title = 'Online';
            } else {
                statusIndicator.innerHTML = '<i class="fas fa-wifi text-danger"></i>';
                statusIndicator.title = 'Offline';
            }
        }
    }

    // Monitor network status
    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);
    updateNetworkStatus(); // Initial call

    console.log('Dashboard loaded successfully');
});

// Utility functions
function showSpinner() {
    const spinner = document.createElement('div');
    spinner.className = 'spinner-overlay';
    spinner.innerHTML = '<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>';
    document.body.appendChild(spinner);
}

function hideSpinner() {
    const spinner = document.querySelector('.spinner-overlay');
    if (spinner) {
        spinner.remove();
    }
}

function showToast(message, type = 'info') {
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;

    // Add to toast container
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        document.body.appendChild(container);
    }

    container.appendChild(toast);

    // Show toast
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();

    // Remove after hide
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}
