from app import db
from datetime import datetime

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='Viewer')  # Admin, Engineer, Viewer
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Server(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    server_name = db.Column(db.String(100), nullable=False)
    ip_address = db.Column(db.String(45), nullable=False)
    space_utilization = db.Column(db.Float, default=0.0)  # Percentage
    hardware_status = db.Column(db.String(20), default='Good')  # Good, Warning, Critical
    volumes_status = db.Column(db.String(20), default='Good')
    remarks = db.Column(db.Text)
    alerts_status = db.Column(db.String(20), default='Normal')  # Normal, Warning, Critical
    system_running = db.Column(db.Boolean, default=True)
    overall_status = db.Column(db.String(20), default='Healthy')  # Healthy, Warning, Critical
    status_by_volume = db.Column(db.String(50))
    protection_group = db.Column(db.String(100))
    failed_backup = db.Column(db.Integer, default=0)
    backup_taken = db.Column(db.Integer, default=0)
    size = db.Column(db.String(20))  # e.g., "500GB", "2TB"
    task_status = db.Column(db.String(20), default='Completed')
    storage_utilization = db.Column(db.Float, default=0.0)  # Percentage
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    
    def __repr__(self):
        return f'<Server {self.server_name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'server_name': self.server_name,
            'ip_address': self.ip_address,
            'space_utilization': self.space_utilization,
            'hardware_status': self.hardware_status,
            'volumes_status': self.volumes_status,
            'remarks': self.remarks,
            'alerts_status': self.alerts_status,
            'system_running': self.system_running,
            'overall_status': self.overall_status,
            'status_by_volume': self.status_by_volume,
            'protection_group': self.protection_group,
            'failed_backup': self.failed_backup,
            'backup_taken': self.backup_taken,
            'size': self.size,
            'task_status': self.task_status,
            'storage_utilization': self.storage_utilization,
            'last_updated': self.last_updated.isoformat() if self.last_updated else None
        }

class Log(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    action = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    server_id = db.Column(db.Integer, db.ForeignKey('server.id'))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    details = db.Column(db.Text)
    
    user = db.relationship('User', backref=db.backref('logs', lazy=True))
    server = db.relationship('Server', backref=db.backref('logs', lazy=True))
    
    def __repr__(self):
        return f'<Log {self.action} by {self.user_id}>'
