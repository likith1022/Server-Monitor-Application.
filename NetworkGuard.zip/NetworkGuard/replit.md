# Server Monitor Application

## Overview

This is a Flask-based web application for monitoring server infrastructure. The application provides a multi-role system where administrators can manage users and servers, engineers can add and update server information, and viewers have read-only access to server status and monitoring data. The system tracks various server metrics including storage utilization, hardware status, backup information, and system health with interactive dashboards and charts for data visualization.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Flask web application with modular design
- **Database**: SQLAlchemy ORM with SQLite as the default database (configurable via DATABASE_URL environment variable)
- **Authentication**: Session-based authentication with password hashing using Werkzeug security utilities
- **Authorization**: Role-based access control with three tiers (Admin, Engineer, Viewer)
- **API Design**: RESTful endpoints for server data and statistics, returning JSON responses

### Frontend Architecture
- **Template Engine**: Jinja2 templates with template inheritance via base.html
- **CSS Framework**: Bootstrap with dark theme for responsive design
- **JavaScript Libraries**: Chart.js for data visualization, vanilla JavaScript for interactivity
- **Design Pattern**: Server-side rendering with AJAX for dynamic content updates

### Data Models
- **User Model**: Stores authentication credentials and role assignments (Admin/Engineer/Viewer)
- **Server Model**: Comprehensive server monitoring data including hardware status, storage metrics, backup information, and operational status
- **Log Model**: Audit trail for user actions and system changes (referenced but not fully implemented)

### Security Implementation
- **Password Security**: Werkzeug password hashing with salt
- **Session Management**: Flask sessions with configurable secret key
- **Access Control**: Decorator-based role checking (@login_required, @role_required)
- **Input Validation**: Form validation on both client and server side

### Monitoring Features
- **Dashboard Views**: Role-specific dashboards with different levels of access
- **Data Visualization**: Interactive charts for storage utilization, backup status, and system health
- **Real-time Updates**: AJAX-based data refresh without page reloads
- **Server Management**: Full CRUD operations for server information

## External Dependencies

### Core Libraries
- **Flask**: Web framework and core application structure
- **SQLAlchemy**: Database ORM and connection management
- **Werkzeug**: Security utilities for password hashing and middleware

### Frontend Dependencies
- **Bootstrap**: CSS framework loaded via CDN for responsive UI components
- **Chart.js**: JavaScript charting library for data visualization dashboards
- **Font Awesome**: Icon library for consistent UI iconography

### Development Tools
- **ProxyFix**: Werkzeug middleware for handling proxy headers in production environments

### Database Configuration
- **SQLite**: Default database with connection pooling and health checks
- **Environment Variables**: DATABASE_URL for production database configuration, SESSION_SECRET for security

### Optional Integrations
- The application structure supports audit logging through the Log model
- Extensible design allows for additional monitoring integrations and external API connections